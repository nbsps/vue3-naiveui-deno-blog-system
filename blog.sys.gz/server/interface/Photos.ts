export default interface Photos {
  id: string;
  url?: string;
  isPublish?: boolean;
}
