export default interface Link {
  id: string;
  avatar?: string;
  title?: string;
  motto?: string;
  isPublish?: boolean;
}
