export default interface Barrage {
  id: string;
  content?: string;
  createdAt?: Date;
  updatedAt?: Date;
}
