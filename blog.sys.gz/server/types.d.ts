export type Next = () => Promise<unknown>;
export type asyncVoid = Promise<void>;
