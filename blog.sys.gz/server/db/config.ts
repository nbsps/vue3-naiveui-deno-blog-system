export const DATABASE = 'blog';
export const TABLES = {
  ARTICLE: 'article',
  BARRAGE: 'barrage',
  LINK: 'link',
  PHOTOS: 'photos',
};
